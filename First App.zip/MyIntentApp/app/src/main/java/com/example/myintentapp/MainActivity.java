package com.example.myintentapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.icu.text.CaseMap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("First App");

        Button btnMoveActivity = findViewById(R.id.btn_move);
        Button btnMoveData = findViewById(R.id.btn_movedata);
        Button btnDial = findViewById(R.id.btn_dial);

        btnMoveActivity.setOnClickListener(this);
        btnMoveData.setOnClickListener(this);
        btnDial.setOnClickListener(this);
    }

    @Override
    public void onClick(View v){
        switch (v.getId()){
            case R.id.btn_move:
                Intent moveIntent = new Intent(MainActivity.this, MoveActivity.class);
                startActivity(moveIntent);
            break;
            case R.id.btn_movedata:
                Intent moveDataIntent = new Intent(MainActivity.this, MoveWithData.class);
                moveDataIntent.putExtra(MoveWithData.EXTRA_NAME, "Muhammad Awaluddin Rusman");
                moveDataIntent.putExtra(MoveWithData.EXTRA_NO, "082283531699");
                moveDataIntent.putExtra(MoveWithData.EXTRA_EMAIL, "170401135@student.umri.ac.id");
                startActivity(moveDataIntent);
                break;
            case R.id.btn_dial:
                String pn = "+62822-8353-1699";
                Intent dialPhone = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+pn));
                Toast.makeText(MainActivity.this, "My Number Awal", Toast.LENGTH_SHORT).show();
                startActivity(dialPhone);
                break;
        }
    }
}
