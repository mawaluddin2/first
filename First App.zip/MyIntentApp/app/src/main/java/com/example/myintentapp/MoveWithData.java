package com.example.myintentapp;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MoveWithData extends AppCompatActivity {
    public static final String EXTRA_NAME = "extra_name";
    public static final String EXTRA_NO = "extra_no";
    public static final String EXTRA_EMAIL = "extra_mail";
   // public static final String EXTRA_FOTO = "extra_foto";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_move_with_data);
        setTitle("Pindah Dengan Data");

        TextView tvDataReceived = findViewById(R.id.tv_data_received);

        String name = getIntent().getStringExtra(EXTRA_NAME);
        String nomor = getIntent().getStringExtra(EXTRA_NO);
        String email = getIntent().getStringExtra(EXTRA_EMAIL);


        String text = name + "\n" + nomor + "\n" + email;
        tvDataReceived.setText(text);
    }
}
